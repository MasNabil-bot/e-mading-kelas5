MADING DIGITAL KELAS 5

File gambar yang dibutuhkan (masing-masing satu gambar besar berisi 10 poster):
- images/maulid.jpg       = gambar mading Maulid Nabi dari Gemini
- images/pancasila.jpg    = gambar mading Hari Lahir Pancasila dari Gemini

Cara pakai:
1. Masukkan kedua gambar ke folder images dengan nama persis seperti di atas.
2. Buka index.html untuk mengecek tampilan.
3. Unggah index.html dan folder images ke repositori GitHub Pages.

Klik gambar untuk memperbesar. Tombol kategori digunakan untuk berganti antara dua gambar mading.
